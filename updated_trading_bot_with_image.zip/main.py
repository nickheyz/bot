import os
import time
import logging
import threading
import pandas as pd
import numpy as np
import ccxt
from telegram import Bot, InputMediaPhoto, Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from io import BytesIO
import matplotlib.pyplot as plt

CONFIG = {
    'TELEGRAM_TOKEN': os.getenv("TELEGRAM_TOKEN"),
    'CHAT_ID': os.getenv("CHAT_ID"),
    'SYMBOLS': ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'LTC/USDT', 'BNB/USDT'],
    'TIMEFRAME': '1m',
    'FETCH_LIMIT': 200,
    'CHECK_INTERVAL': 60,
}

bot = Bot(token=CONFIG['TELEGRAM_TOKEN'])
updater = Updater(token=CONFIG['TELEGRAM_TOKEN'], use_context=True)
dispatcher = updater.dispatcher
last_signals = {s: None for s in CONFIG['SYMBOLS']}
exchange = ccxt.mexc({'enableRateLimit': True})

def fetch_data(symbol):
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe=CONFIG['TIMEFRAME'], limit=CONFIG['FETCH_LIMIT'])
    df = pd.DataFrame(ohlcv, columns=['ts', 'open', 'high', 'low', 'close', 'volume'])
    df['ts'] = pd.to_datetime(df['ts'], unit='ms')
    return df

def compute_indicators(df):
    df['ema7'] = df['close'].ewm(span=7).mean()
    df['ema14'] = df['close'].ewm(span=14).mean()
    df['ema28'] = df['close'].ewm(span=28).mean()
    df['macd'] = df['close'].ewm(span=12).mean() - df['close'].ewm(span=26).mean()
    df['signal'] = df['macd'].ewm(span=9).mean()
    df['hist'] = df['macd'] - df['signal']
    df['rsi'] = compute_rsi(df['close'])
    return df

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).rolling(period).mean()
    avg_loss = pd.Series(loss).rolling(period).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def plot_chart(df, symbol):
    plt.figure(figsize=(10, 4))
    plt.plot(df['ts'], df['close'], label='Close')
    plt.plot(df['ts'], df['ema7'], label='EMA7')
    plt.plot(df['ts'], df['ema14'], label='EMA14')
    plt.plot(df['ts'], df['ema28'], label='EMA28')
    plt.title(symbol)
    plt.legend()
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plt.close()
    return buf

def analyze(symbol):
    global last_signals
    try:
        df = fetch_data(symbol)
        df = compute_indicators(df)
        latest = df.iloc[-1]

        bull = latest['ema7'] > latest['ema14'] > latest['ema28'] and latest['hist'] > 0 and latest['rsi'] > 50
        bear = latest['ema7'] < latest['ema14'] < latest['ema28'] and latest['hist'] < 0 and latest['rsi'] < 50

        signal = None
        if bull:
            signal = 'LONG'
        elif bear:
            signal = 'SHORT'

        if signal and signal != last_signals[symbol]:
            img = plot_chart(df, symbol)
            direction = "🟢 LONG" if signal == 'LONG' else "🔴 SHORT"
            spot_or_futures = "Futures (1x–5x)"
            hold_time = "4–12h" if signal == 'LONG' else "1–6h"
            explanation = f"🚀 Сигнал основан на пересечении EMA, MACD и RSI. Уверенное направление движения подтверждено объёмом."

            msg = (
                f"⚡️ <b>${symbol}</b> #{symbol.replace('/', '')}
"
                f"{direction} сигнал на <b>{spot_or_futures}</b>

"
                f"💰 Цена: <code>{latest['close']:.2f}</code>
"
                f"📊 RSI: <code>{latest['rsi']:.2f}</code>
"
                f"📈 MACD hist: <code>{latest['hist']:.4f}</code>

"
                f"{explanation}
"
                f"⏳ Держать примерно: <b>{hold_time}</b>

"
                f"#crypto #{signal.lower()} #{symbol.split('/')[0].lower()} ${symbol.split('/')[0]}"
            )

            bot.send_photo(chat_id=CONFIG['CHAT_ID'], photo=img, caption=msg, parse_mode='HTML')
            last_signals[symbol] = signal
    except Exception as e:
        logging.error(f"Ошибка анализа {symbol}: {e}")

def cmd_post(update: Update, ctx: CallbackContext):
    update.message.reply_text("🔍 Анализирую рынок...")
    for symbol in CONFIG['SYMBOLS']:
        analyze(symbol)

dispatcher.add_handler(CommandHandler("post", cmd_post))

def loop():
    while True:
        for symbol in CONFIG['SYMBOLS']:
            analyze(symbol)
        time.sleep(CONFIG['CHECK_INTERVAL'])

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    t = threading.Thread(target=loop, daemon=True)
    updater.start_polling()
    t.start()
    updater.idle()